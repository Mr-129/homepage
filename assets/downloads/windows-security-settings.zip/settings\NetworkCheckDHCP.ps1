﻿# Get-Netipaddress -InterfaceAlias "イーサネット" -AddressFamily "IPv4"
(Get-Netipaddress -InterfaceAlias "イーサネット" -AddressFamily "IPv4" ).PrefixOrigin