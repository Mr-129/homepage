﻿# 指定したレジストリパスを .reg ファイルとしてバックアップするスクリプト
# - 入力は HKLM:\... 形式 / HKEY_LOCAL_MACHINE\... 形式の両方に対応
# - パス存在確認後に reg.exe export で保存
#
# コマンドライン実行例:
# 1) HKLM: 形式で指定
#    powershell -ExecutionPolicy Bypass -File .\settings\RegistryPathBackup.ps1 -RegistryPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation"
# 2) HKEY_ フル名形式で指定
#    powershell -ExecutionPolicy Bypass -File .\settings\RegistryPathBackup.ps1 -RegistryPath "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation"
# 3) 出力先フォルダーを指定
#    powershell -ExecutionPolicy Bypass -File .\settings\RegistryPathBackup.ps1 -RegistryPath "HKCU:\Software" -OutputDirectory "C:\temp\regbackup"

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RegistryPath,

    [string]$OutputDirectory = "$PSScriptRoot\\backup"
)

# エラー発生時は処理を即時停止する
$ErrorActionPreference = "Stop"

# PowerShell の Test-Path で確認できる形式に正規化する
# 例: HKEY_LOCAL_MACHINE\Software -> Registry::HKEY_LOCAL_MACHINE\Software
function Convert-ToProviderPath {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    $trimmed = $Path.Trim()

    if ($trimmed -match '^(HKLM|HKCU|HKCR|HKU|HKCC):\\') {
        return $trimmed
    }

    if ($trimmed -match '^(HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|HKEY_CLASSES_ROOT|HKEY_USERS|HKEY_CURRENT_CONFIG)\\') {
        return "Registry::$trimmed"
    }

    throw "未対応のレジストリパス形式です: $Path"
}

# reg.exe export 用のルート名に正規化する
# 例: HKLM:\Software -> HKEY_LOCAL_MACHINE\Software
function Convert-ToRegExePath {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    $trimmed = $Path.Trim()

    if ($trimmed -match '^HKLM:\\(.+)$') { return "HKEY_LOCAL_MACHINE\\$($Matches[1])" }
    if ($trimmed -match '^HKCU:\\(.+)$') { return "HKEY_CURRENT_USER\\$($Matches[1])" }
    if ($trimmed -match '^HKCR:\\(.+)$') { return "HKEY_CLASSES_ROOT\\$($Matches[1])" }
    if ($trimmed -match '^HKU:\\(.+)$')  { return "HKEY_USERS\\$($Matches[1])" }
    if ($trimmed -match '^HKCC:\\(.+)$') { return "HKEY_CURRENT_CONFIG\\$($Matches[1])" }

    if ($trimmed -match '^(HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|HKEY_CLASSES_ROOT|HKEY_USERS|HKEY_CURRENT_CONFIG)\\') {
        return $trimmed
    }

    throw "未対応のレジストリパス形式です: $Path"
}

# 入力パスを用途別に変換
$providerPath = Convert-ToProviderPath -Path $RegistryPath
$regExePath = Convert-ToRegExePath -Path $RegistryPath

# 指定したレジストリキーが存在しない場合はエラー
if (-not (Test-Path -Path $providerPath)) {
    throw "指定したレジストリパスが存在しません: $RegistryPath"
}

# 出力先フォルダーがなければ作成
if (-not (Test-Path -Path $OutputDirectory)) {
    New-Item -Path $OutputDirectory -ItemType Directory -Force | Out-Null
}

# 保存ファイル名を生成（時刻付き・ファイル名に使えない文字は置換）
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$safeName = ($regExePath -replace '[\\/:*?""<>|]', '_')
$outputFile = Join-Path -Path $OutputDirectory -ChildPath ("{0}_{1}.reg" -f $safeName, $timestamp)

# レジストリをエクスポート
& reg.exe export "$regExePath" "$outputFile" /y | Out-Null

# reg.exe の終了コードを確認
if ($LASTEXITCODE -ne 0) {
    throw "reg export に失敗しました。終了コード: $LASTEXITCODE"
}

# 成功メッセージ（人向け）
Write-Host "バックアップを保存しました: $outputFile"

# 戻り値（スクリプト連携向け）
# 注意: コンソール実行時は Write-Host と Write-Output の両方が表示される
Write-Output ([PSCustomObject]@{
    RegistryPath = $regExePath
    OutputFile   = $outputFile
    ExportedAt   = (Get-Date).ToString("o")
})
