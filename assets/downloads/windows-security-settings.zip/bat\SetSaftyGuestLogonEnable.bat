@echo off
setlocal

set "SETUP_BAT=%~dp0setup.bat"

if not exist "%SETUP_BAT%" (
	echo [ERROR] ランチャーが見つかりません: "%SETUP_BAT%"
	pause
	exit /b 2
)

call "%SETUP_BAT%" settings\SaftyGuestLogonEnable.ps1
exit /b %errorlevel%