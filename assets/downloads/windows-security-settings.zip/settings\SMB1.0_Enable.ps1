﻿# SMB1.0 関連機能を有効化するスクリプト
# - SMB1Protocol / SMB1Protocol-Client / SMB1Protocol-Server を有効化
# - SMB1Protocol-Deprecation を無効化（自動削除を防止）
# - 実行後に状態を再確認し、結果をオブジェクトで返す
#
# コマンドライン使用例:
# 1) 通常実行
#    powershell -ExecutionPolicy Bypass -File .\settings\SMB1.0_Enable.ps1
# 2) 呼び出し元で戻り値を受け取る
#    $result = & .\settings\SMB1.0_Enable.ps1

[CmdletBinding()]
param()

# エラー発生時は即時停止
$ErrorActionPreference = "Stop"

$commonScriptPath = Join-Path -Path $PSScriptRoot -ChildPath "CommonFunctions.ps1"
if (-not (Test-Path -Path $commonScriptPath)) {
	throw "共通関数スクリプトが見つかりません: $commonScriptPath"
}
. $commonScriptPath

# Windows オプション機能の現在状態を取得
function Get-FeatureState {
	param(
		[Parameter(Mandatory = $true)][string]$FeatureName
	)

	return (Get-WindowsOptionalFeature -Online -FeatureName $FeatureName -ErrorAction Stop).State
}

# 目標状態（Enabled/Disabled）へ変更し、変更後状態を検証して返す
function Ensure-FeatureState {
	param(
		[Parameter(Mandatory = $true)][string]$FeatureName,
		[Parameter(Mandatory = $true)][ValidateSet("Enabled", "Disabled")][string]$TargetState
	)

	$beforeState = Get-FeatureState -FeatureName $FeatureName
	$restartNeeded = $false

	if ($TargetState -eq "Enabled" -and $beforeState -ne "Enabled") {
		$result = Enable-WindowsOptionalFeature -Online -FeatureName $FeatureName -NoRestart -ErrorAction Stop
		$restartNeeded = $result.RestartNeeded
	}
	elseif ($TargetState -eq "Disabled" -and $beforeState -ne "Disabled") {
		$result = Disable-WindowsOptionalFeature -Online -FeatureName $FeatureName -NoRestart -ErrorAction Stop
		$restartNeeded = $result.RestartNeeded
	}

	$afterState = Get-FeatureState -FeatureName $FeatureName
	if ($afterState -ne $TargetState) {
		throw "機能状態の検証に失敗しました: $FeatureName (期待値=$TargetState, 現在値=$afterState)"
	}

	return [PSCustomObject]@{
		FeatureName   = $FeatureName
		BeforeState   = $beforeState
		AfterState    = $afterState
		RestartNeeded = [bool]$restartNeeded
	}
}

try {
	# 1) 管理者権限チェック
	if (-not (Test-IsAdministrator)) {
		throw "このスクリプトは管理者権限で実行してください。"
	}

	# 2) SMB1 本体 / クライアント / サーバーを有効化
	$protocolResult = Ensure-FeatureState -FeatureName "SMB1Protocol" -TargetState "Enabled"
	Write-Host "SMB1.0プロトコル 有効化 : OK"

	$clientResult = Ensure-FeatureState -FeatureName "SMB1Protocol-Client" -TargetState "Enabled"
	Write-Host "SMB1.0クライアント 有効化 : OK"

	$serverResult = Ensure-FeatureState -FeatureName "SMB1Protocol-Server" -TargetState "Enabled"
	Write-Host "SMB1.0サーバー 有効化 : OK"

	# 3) SMB1 自動削除(Deprecation)は無効化
	$deprecationResult = Ensure-FeatureState -FeatureName "SMB1Protocol-Deprecation" -TargetState "Disabled"
	Write-Host "SMB1.0自動削除無効化 : OK"

	# 4) いずれかの変更で再起動が必要か判定
	$restartNeeded = @(
		$protocolResult.RestartNeeded,
		$clientResult.RestartNeeded,
		$serverResult.RestartNeeded,
		$deprecationResult.RestartNeeded
	) -contains $true

	if ($restartNeeded) {
		Write-Warning "変更反映には再起動が必要です。"
	}

	$changed = @($protocolResult, $clientResult, $serverResult, $deprecationResult) |
		Where-Object { $_.BeforeState -ne $_.AfterState } |
		Measure-Object |
		Select-Object -ExpandProperty Count

	# 5) 呼び出し元連携用に結果オブジェクトを返す
	Write-Output (New-ScriptResult -ScriptName "SMB1.0_Enable" -Changed ($changed -gt 0) -Data @{
		RestartNeeded = $restartNeeded
		Results = @($protocolResult, $clientResult, $serverResult, $deprecationResult)
	})

	# 成功終了
	exit 0
}
catch {
	# 失敗時はエラー表示と終了コード1
	Write-Error "SMB1.0設定変更 : NG - $($_.Exception.Message)"
	exit 1
}