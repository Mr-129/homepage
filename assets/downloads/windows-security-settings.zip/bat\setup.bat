@echo off
setlocal

chcp 65001 >nul
set "LAUNCHER_PS1=%~dp0setup-launcher.ps1"

if not exist "%LAUNCHER_PS1%" (
	echo [ERROR] ランチャースクリプトが見つかりません: "%LAUNCHER_PS1%"
	pause
	exit /b 2
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%LAUNCHER_PS1%" -RequireAdmin -PauseOnExit %*
set "PS_EXIT=%errorlevel%"

if "%PS_EXIT%"=="0" (
	echo [OK] 正常終了
) else (
	echo [NG] 異常終了 (ExitCode=%PS_EXIT%)
)

pause
exit /b %PS_EXIT%