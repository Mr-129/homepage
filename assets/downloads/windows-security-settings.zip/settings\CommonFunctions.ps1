﻿# 設定変更スクリプトで共通利用する関数群

# 管理者権限で実行されているかを判定する
function Test-IsAdministrator {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

# レジストリ DWORD 値を目標値に合わせる
# - キーが存在しない場合は作成する
# - 既に目標値なら変更しない
function Ensure-RegistryDwordValue {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][int]$Value
    )

    if (-not (Test-Path -Path $Path)) {
        New-Item -Path $Path -Force | Out-Null
    }

    $beforeValue = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue).$Name
    if ($beforeValue -eq $Value) {
        return [PSCustomObject]@{
            Path        = $Path
            Name        = $Name
            BeforeValue = $beforeValue
            AfterValue  = $beforeValue
            Changed     = $false
        }
    }

    New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType DWord -Force | Out-Null

    return [PSCustomObject]@{
        Path        = $Path
        Name        = $Name
        BeforeValue = $beforeValue
        AfterValue  = $Value
        Changed     = $true
    }
}

# 呼び出し元スクリプト向けの標準結果オブジェクトを生成する
function New-ScriptResult {
    param(
        [Parameter(Mandatory = $true)][string]$ScriptName,
        [bool]$Changed = $false,
        [hashtable]$Data = @{}
    )

    $result = [ordered]@{
        ScriptName = $ScriptName
        Changed    = $Changed
        ExecutedAt = (Get-Date).ToString("o")
    }

    foreach ($key in $Data.Keys) {
        $result[$key] = $Data[$key]
    }

    return [PSCustomObject]$result
}
