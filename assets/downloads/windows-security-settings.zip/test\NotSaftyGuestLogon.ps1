﻿# 安全でないゲストログオンを有効化確認
# レジストリ値が未作成でも例外終了せず、未設定として扱う。
# BAT ランチャーが結果を判定できるよう、OK/NG に応じた終了コードを返す。
$expectedValue = 1
#$result = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "AllowInsecureGuestAuth").AllowInsecureGuestAuth
$property = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation" -Name "AllowInsecureGuestAuth" -ErrorAction SilentlyContinue
$result = $property.AllowInsecureGuestAuth

if ($null -eq $result) {
    Write-Host "安全でないゲストログオンを有効化 : 未設定"
    exit 1
}

if ($expectedValue -eq $result) {
    Write-Host "安全でないゲストログオンを有効化 : OK"
    exit 0
}

Write-Host "安全でないゲストログオンを有効化 : NG"
exit 1