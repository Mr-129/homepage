﻿# SMB1の有効化チェック
# BAT ランチャーが結果を判定できるよう、全項目 OK のときだけ終了コード 0 を返す。
$hasFailure = $false

# SMB1クライアント有効化確認
$smbClientState = (Get-WindowsOptionalFeature -Online -FeatureName "SMB1Protocol-Client").State

if ($smbClientState -eq "Enabled") {
	Write-Host "SMB1クライアント 有効化 : OK"
} else {
	Write-Host "SMB1クライアント 有効化 : NG"
	$hasFailure = $true
}

# SMB1サーバー有効化確認
$smbServerState = (Get-WindowsOptionalFeature -Online -FeatureName "SMB1Protocol-Server").State

if ($smbServerState -eq "Enabled") {
	Write-Host "SMB1サーバー 有効化 : OK"
} else {
	Write-Host "SMB1サーバー 有効化 : NG"
	$hasFailure = $true
}

# SMB1自動削除無効化確認
$smbDeprecationState = (Get-WindowsOptionalFeature -Online -FeatureName "SMB1Protocol-Deprecation").State

if ($smbDeprecationState -eq "Disabled") {
	Write-Host "SMB1自動削除 無効化 : OK"
} else {
	Write-Host "SMB1自動削除 無効化 : NG"
	$hasFailure = $true
}

if ($hasFailure) {
	exit 1
}

exit 0