﻿# 安全でないゲストログオンを有効化するスクリプト
# - ポリシーレジストリキーに値を直接設定（管理用テンプレート設定）
# - gpupdate は実行しない（GPO 未構成時に値がクリアされるのを防止）
# - 最後に設定値を再確認して結果を表示

[CmdletBinding()]
param(
	[switch]$SkipGpUpdate
)

# 途中で失敗した場合は即時停止する
$ErrorActionPreference = "Stop"

$commonScriptPath = Join-Path -Path $PSScriptRoot -ChildPath "CommonFunctions.ps1"
if (-not (Test-Path -Path $commonScriptPath)) {
	throw "共通関数スクリプトが見つかりません: $commonScriptPath"
}
. $commonScriptPath

# 管理者権限でなければ終了
if (-not (Test-IsAdministrator)) {
	throw "このスクリプトは管理者権限で実行してください。"
}

# 設定対象のレジストリ情報
# policyPath : ローカル/ドメインGPOで管理されるポリシー側
$policyPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation"
$name = "AllowInsecureGuestAuth"
$targetValue = 1

# 1) ポリシーキーを設定
$policyResult = Ensure-RegistryDwordValue -Path $policyPath -Name $name -Value $targetValue
$policyChanged = $policyResult.Changed

$changed = $policyChanged

# 注意: ポリシーレジストリキー (HKLM:\SOFTWARE\Policies\...) への直接書き込みは
# 管理用テンプレートの設定として即座に反映されるため gpupdate は不要です。
# gpupdate /force を実行すると、GPO 側で未構成の場合に手動設定した値が
# クリアされる可能性があるため、ここでは実行しません。

# 2) 設定値を読み戻して検証
$policyValue = (Get-ItemProperty -Path $policyPath -Name $name -ErrorAction SilentlyContinue).$name

if ($policyValue -ne $targetValue) {
	throw "ポリシー値の設定に失敗しました。現在値: $policyValue"
}

# 4) 結果表示
if ($changed) {
	Write-Host "安全でないゲストログオンを有効化 : OK"
}
else {
	Write-Host "安全でないゲストログオンを有効化 : 変更不要（既に目標値）"
}
Write-Host "PolicyKey  : $policyPath\\$name = $policyValue"

Write-Output (New-ScriptResult -ScriptName "SaftyGuestLogonEnable" -Changed $changed -Data @{
	PolicyValue = $policyValue
})

# ドメイン参加端末はドメインGPOで上書きされる可能性があるため注意喚起
if ((Get-CimInstance -ClassName Win32_ComputerSystem).PartOfDomain) {
	Write-Warning "ドメイン参加端末です。ドメインGPOが無効化を配布している場合、次回ポリシー更新で値が戻る可能性があります。"
}
