@echo off
setlocal

set "LAUNCHER_PS1=%~dp0setup-launcher.ps1"

if not exist "%LAUNCHER_PS1%" (
	echo [ERROR] ランチャースクリプトが見つかりません: "%LAUNCHER_PS1%"
	pause
	exit /b 2
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%LAUNCHER_PS1%" -RequireAdmin -PauseOnExit test\SMB_Settings.ps1
set "PS_EXIT=%errorlevel%"

if "%PS_EXIT%"=="0" (
	echo [OK] 実行完了
) else (
	echo [NG] 異常終了 (ExitCode=%PS_EXIT%)
)

pause
exit /b %PS_EXIT%