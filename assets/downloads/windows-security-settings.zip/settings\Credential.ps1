# 資格情報を取得して変数に保存
$credential = Get-Credential

# 資格情報のユーザー名を確認
$credential.UserName
$credential.Password