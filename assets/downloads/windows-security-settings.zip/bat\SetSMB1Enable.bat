@echo off
setlocal

set "SETUP_BAT=%~dp0setup.bat"

if not exist "%SETUP_BAT%" (
	echo [ERROR] ランチャーが見つかりません: "%SETUP_BAT%"
	pause
	exit /b 2
)

call "%SETUP_BAT%" settings\SMB1.0_Enable.ps1
exit /b %errorlevel%