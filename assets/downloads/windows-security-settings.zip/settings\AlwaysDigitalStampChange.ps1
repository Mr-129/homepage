﻿# Microsoft ネットワーク クライアント:
# 「常にデジタル署名を行う (RequireSecuritySignature)」を無効化するスクリプト
#
# ローカルセキュリティポリシー (secedit) を使用して設定を変更します。
# この設定は「セキュリティオプション」に分類されるため、
# レジストリ直接書き込みではグループポリシーエディター (gpedit.msc)
# に反映されず、また GP 未構成時にはレジストリ値自体が存在しません。
# secedit 経由で変更することで両方の問題を解決します。
#
# コマンドライン実行例:
# 1) 通常実行（変更前バックアップあり）
#    powershell -ExecutionPolicy Bypass -File .\settings\AlwaysDigitalStampChange.ps1
# 2) バックアップを省略して実行
#    powershell -ExecutionPolicy Bypass -File .\settings\AlwaysDigitalStampChange.ps1 -SkipBackup

[CmdletBinding()]
param(
	[switch]$SkipBackup
)

# エラー発生時は即時停止する
$ErrorActionPreference = "Stop"

$commonScriptPath = Join-Path -Path $PSScriptRoot -ChildPath "CommonFunctions.ps1"
if (-not (Test-Path -Path $commonScriptPath)) {
	throw "共通関数スクリプトが見つかりません: $commonScriptPath"
}
. $commonScriptPath

# 変更対象の設定情報
# secedit の [Registry Values] セクションで使用するキー名
$seceditKey = "MACHINE\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\RequireSecuritySignature"
# 検証用レジストリパス
$registryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"
$registryName = "RequireSecuritySignature"
$targetValue = 0

try {
	# 1) 管理者権限チェック
	if (-not (Test-IsAdministrator)) {
		throw "このスクリプトは管理者権限で実行してください。"
	}

	# 2) 現在のレジストリ値を取得（GP 未構成の場合は値が存在しない）
	$beforeValue = (Get-ItemProperty -Path $registryPath -Name $registryName -ErrorAction SilentlyContinue).$registryName

	if ($null -ne $beforeValue -and $beforeValue -eq $targetValue) {
		Write-Host "常にデジタル署名を行う無効化 : 変更不要（既に目標値）"
		Write-Output (New-ScriptResult -ScriptName "AlwaysDigitalStampChange" -Changed $false -Data @{
			Path        = $registryPath
			Name        = $registryName
			BeforeValue = $beforeValue
			Value       = $beforeValue
			BackupFile  = $null
		})
		exit 0
	}

	# 3) 変更前バックアップ（既定で実施）
	$backupResult = $null
	if (-not $SkipBackup) {
		$backupScriptPath = Join-Path -Path $PSScriptRoot -ChildPath "RegistryPathBackup.ps1"
		if (-not (Test-Path -Path $backupScriptPath)) {
			throw "バックアップスクリプトが見つかりません: $backupScriptPath"
		}
		if (Test-Path -Path $registryPath) {
			$backupResult = & $backupScriptPath -RegistryPath $registryPath
			Write-Host "変更前バックアップ : $($backupResult.OutputFile)"
		}
	}

	# 4) secedit で現在のセキュリティポリシーをエクスポート
	$tempDir = Join-Path -Path $env:TEMP -ChildPath "AlwaysDigitalStampChange_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
	New-Item -Path $tempDir -ItemType Directory -Force | Out-Null

	$exportCfg = Join-Path -Path $tempDir -ChildPath "export.cfg"
	$modifiedCfg = Join-Path -Path $tempDir -ChildPath "modified.cfg"
	$tempSdb = Join-Path -Path $tempDir -ChildPath "secedit.sdb"

	& secedit /export /cfg $exportCfg /quiet 2>&1 | Out-Null
	if ($LASTEXITCODE -ne 0) {
		throw "secedit /export に失敗しました (ExitCode=$LASTEXITCODE)"
	}

	# 5) エクスポートファイルを編集して RequireSecuritySignature を無効化
	$cfgContent = Get-Content -Path $exportCfg -Raw
	$settingLine = "$seceditKey=4,$targetValue"
	$escapedKey = [regex]::Escape($seceditKey)

	if ($cfgContent -match "$escapedKey=") {
		# 既存の設定行を置換
		$cfgContent = $cfgContent -replace "$escapedKey=\d+,\d+", $settingLine
	}
	elseif ($cfgContent -match '\[Registry Values\]') {
		# [Registry Values] セクションに追加
		$cfgContent = $cfgContent -replace '(\[Registry Values\])', "`$1`r`n$settingLine"
	}
	else {
		# [Registry Values] セクション自体を追加
		$cfgContent += "`r`n[Registry Values]`r`n$settingLine`r`n"
	}

	Set-Content -Path $modifiedCfg -Value $cfgContent -Encoding Unicode -NoNewline

	# 6) 変更したポリシーを適用
	& secedit /configure /db $tempSdb /cfg $modifiedCfg /areas SECURITYPOLICY /quiet 2>&1 | Out-Null
	if ($LASTEXITCODE -ne 0) {
		throw "secedit /configure に失敗しました (ExitCode=$LASTEXITCODE)"
	}

	# 7) 一時ファイルを削除
	Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue

	# 8) 変更後のレジストリ値を検証
	$reloadedValue = (Get-ItemProperty -Path $registryPath -Name $registryName -ErrorAction SilentlyContinue).$registryName
	if ($null -eq $reloadedValue -or $reloadedValue -ne $targetValue) {
		throw "変更後の検証に失敗しました。現在値: $reloadedValue"
	}

	# 9) 成功表示と結果出力
	Write-Host "常にデジタル署名を行う無効化 : OK"
	Write-Output (New-ScriptResult -ScriptName "AlwaysDigitalStampChange" -Changed $true -Data @{
		Path        = $registryPath
		Name        = $registryName
		BeforeValue = $beforeValue
		Value       = $reloadedValue
		BackupFile  = if ($backupResult) { $backupResult.OutputFile } else { $null }
	})

	exit 0
}
catch {
	# 一時ファイルクリーンアップ
	if ($tempDir -and (Test-Path -Path $tempDir)) {
		Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
	}
	Write-Error "常にデジタル署名を行う無効化 : NG - $($_.Exception.Message)"
	exit 1
}