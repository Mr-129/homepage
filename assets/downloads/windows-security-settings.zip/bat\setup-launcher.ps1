[CmdletBinding()]
param(
	[string]$TargetRel = "settings\SMB1.0_Enable.ps1",
	[switch]$PauseOnExit,
	[switch]$Elevated,
	[switch]$RequireAdmin,
	[Parameter(ValueFromRemainingArguments = $true)]
	[string[]]$ScriptArgs
)

$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
	$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
	return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Wait-ForUserIfNeeded {
	param(
		[int]$ExitCode
	)

	if ($PauseOnExit) {
		Write-Host ""
		Read-Host "Press Enter to close" | Out-Null
	}

	exit $ExitCode
}

$baseDir = Split-Path -Path $PSScriptRoot -Parent
$targetPath = Join-Path -Path $baseDir -ChildPath $TargetRel

if (-not (Test-Path -Path $targetPath)) {
	Write-Error "Script not found: $targetPath"
	Wait-ForUserIfNeeded -ExitCode 2
}

if ($RequireAdmin -and (-not (Test-IsAdministrator))) {
	Write-Host "Restarting with administrator privileges..."

	$argumentList = @(
		'-NoProfile'
		'-ExecutionPolicy'
		'Bypass'
		'-File'
		$PSCommandPath
		'-TargetRel'
		$TargetRel
		'-Elevated'
		'-RequireAdmin'
	)

	if ($PauseOnExit) {
		$argumentList += '-PauseOnExit'
	}

	if ($ScriptArgs) {
		$argumentList += $ScriptArgs
	}

	try {
		$process = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argumentList -PassThru -Wait
		Wait-ForUserIfNeeded -ExitCode $process.ExitCode
	}
	catch {
		Write-Error "Failed to restart as administrator: $($_.Exception.Message)"
		Wait-ForUserIfNeeded -ExitCode 1
	}
}

Write-Host "[INFO] Target script: $targetPath"

try {
	$childArguments = @(
		'-NoProfile'
		'-ExecutionPolicy'
		'Bypass'
		'-File'
		$targetPath
	)

	if ($ScriptArgs) {
		$childArguments += $ScriptArgs
	}

	& powershell.exe @childArguments
	$exitCode = if ($null -ne $LASTEXITCODE) { $LASTEXITCODE } else { 0 }
	Wait-ForUserIfNeeded -ExitCode $exitCode
}
catch {
	Write-Error "Execution failed: $($_.Exception.Message)"
	Wait-ForUserIfNeeded -ExitCode 1
}