﻿# 常にデジタル署名を行う無効化確認
# レジストリ値が未作成でも例外終了せず、未設定として扱う。
# BAT ランチャーが結果を判定できるよう、OK/NG に応じた終了コードを返す。
$expectedValue = 0
$property = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "RequireSecuritySignature" -ErrorAction SilentlyContinue
$result = $property.RequireSecuritySignature

if ($null -eq $result) {
    Write-Host "常にデジタル署名を行う無効化 : 未設定"
    exit 1
}

if ($expectedValue -eq $result) {
    Write-Host "常にデジタル署名を行う無効化 : OK"
    exit 0
}

Write-Host "常にデジタル署名を行う無効化 : NG"
exit 1
